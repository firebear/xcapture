function V(e,t=5e3){return new Promise(n=>{const r=document.querySelector(e);if(r){n(r);return}const s=new MutationObserver(()=>{const o=document.querySelector(e);o&&(s.disconnect(),n(o))});s.observe(document.body,{childList:!0,subtree:!0}),setTimeout(()=>{s.disconnect(),n(null)},t)})}class W{constructor(){this.observer=null,this.processedTweets=new Set}async start(t){await V('[data-testid="primaryColumn"]'),this.observer=new MutationObserver(r=>{r.forEach(s=>{s.addedNodes.forEach(o=>{o instanceof HTMLElement&&this.findTweets(o,t)})})}),this.observer.observe(document.body,{childList:!0,subtree:!0}),document.querySelectorAll('[data-testid="tweet"]').forEach(r=>{r instanceof HTMLElement&&t(r)})}findTweets(t,n){t.querySelectorAll('[data-testid="tweet"]').forEach(s=>{s instanceof HTMLElement&&!this.processedTweets.has(s)&&(this.processedTweets.add(s),n(s))})}stop(){this.observer&&(this.observer.disconnect(),this.observer=null),this.processedTweets.clear()}}const O="xcapture-button";class j{constructor(){this.injectedButtons=new Set}inject(t,n){if(this.injectedButtons.has(t))return;const r=t.querySelector('[role="group"]');if(!r)return;const s=this.createButton(n);r.appendChild(s),this.injectedButtons.add(t)}createButton(t){const n=document.createElement("button");return n.id=O,n.innerHTML=this.getSVGIcon(),n.style.cssText=`
      background-color: transparent;
      border: none;
      cursor: pointer;
      padding: 8px;
      border-radius: 9999px;
      display: flex;
      align-items: center;
      justify-content: center;
      transition: background-color 0.2s;
    `,n.addEventListener("mouseenter",()=>{n.style.backgroundColor="rgba(29, 155, 240, 0.1)"}),n.addEventListener("mouseleave",()=>{n.style.backgroundColor="transparent"}),n.addEventListener("click",r=>{r.preventDefault(),r.stopPropagation(),t()}),n}getSVGIcon(){return`
      <svg viewBox="0 0 1024 1024" width="18" height="18" fill="rgb(113, 118, 123)">
        <path d="M224 779.712l-0.128-439.712h146.976l45.856-106.048c1.856-4.256 10.496-9.952 15.136-9.952h192.288c4.768 0 13.248 5.6 15.136 9.92l45.856 106.08 146.88 0.32 0.032 439.68L224 779.68zM832.032 276h-104.832l-29.184-67.52C686.016 180.896 654.272 160 624.128 160h-192.288c-30.144 0-61.888 20.864-73.856 48.544l-29.184 67.456H223.968A64.224 64.224 0 0 0 160 340.32v439.36c0 35.488 28.672 64.32 63.968 64.32h608.064A64.192 64.192 0 0 0 896 779.68v-439.36c0-35.456-28.704-64.32-63.968-64.32z"/>
        <path d="M528 640c-52.928 0-96-43.072-96-96s43.072-96 96-96 96 43.072 96 96-43.072 96-96 96m0-256c-88.224 0-160 71.776-160 160s71.776 160 160 160 160-71.776 160-160-71.776-160-160-160"/>
      </svg>
    `}}function _(e,t){if(e.match(/^[a-z]+:\/\//i))return e;if(e.match(/^\/\//))return window.location.protocol+e;if(e.match(/^[a-z]+:/i))return e;const n=document.implementation.createHTMLDocument(),r=n.createElement("base"),s=n.createElement("a");return n.head.appendChild(r),n.body.appendChild(s),t&&(r.href=t),s.href=e,s.href}const X=(()=>{let e=0;const t=()=>`0000${(Math.random()*36**4<<0).toString(36)}`.slice(-4);return()=>(e+=1,`u${t()}${e}`)})();function g(e){const t=[];for(let n=0,r=e.length;n<r;n++)t.push(e[n]);return t}let p=null;function k(e={}){return p||(e.includeStyleProperties?(p=e.includeStyleProperties,p):(p=g(window.getComputedStyle(document.documentElement)),p))}function y(e,t){const r=(e.ownerDocument.defaultView||window).getComputedStyle(e).getPropertyValue(t);return r?parseFloat(r.replace("px","")):0}function G(e){const t=y(e,"border-left-width"),n=y(e,"border-right-width");return e.clientWidth+t+n}function K(e){const t=y(e,"border-top-width"),n=y(e,"border-bottom-width");return e.clientHeight+t+n}function M(e,t={}){const n=t.width||G(e),r=t.height||K(e);return{width:n,height:r}}function N(){let e,t;try{t=process}catch{}const n=t&&t.env?t.env.devicePixelRatio:null;return n&&(e=parseInt(n,10),Number.isNaN(e)&&(e=1)),e||window.devicePixelRatio||1}const f=16384;function J(e){(e.width>f||e.height>f)&&(e.width>f&&e.height>f?e.width>e.height?(e.height*=f/e.width,e.width=f):(e.width*=f/e.height,e.height=f):e.width>f?(e.height*=f/e.width,e.width=f):(e.width*=f/e.height,e.height=f))}function b(e){return new Promise((t,n)=>{const r=new Image;r.onload=()=>{r.decode().then(()=>{requestAnimationFrame(()=>t(r))})},r.onerror=n,r.crossOrigin="anonymous",r.decoding="async",r.src=e})}async function Q(e){return Promise.resolve().then(()=>new XMLSerializer().serializeToString(e)).then(encodeURIComponent).then(t=>`data:image/svg+xml;charset=utf-8,${t}`)}async function Y(e,t,n){const r="http://www.w3.org/2000/svg",s=document.createElementNS(r,"svg"),o=document.createElementNS(r,"foreignObject");return s.setAttribute("width",`${t}`),s.setAttribute("height",`${n}`),s.setAttribute("viewBox",`0 0 ${t} ${n}`),o.setAttribute("width","100%"),o.setAttribute("height","100%"),o.setAttribute("x","0"),o.setAttribute("y","0"),o.setAttribute("externalResourcesRequired","true"),s.appendChild(o),o.appendChild(e),Q(s)}const d=(e,t)=>{if(e instanceof t)return!0;const n=Object.getPrototypeOf(e);return n===null?!1:n.constructor.name===t.name||d(n,t)};function Z(e){const t=e.getPropertyValue("content");return`${e.cssText} content: '${t.replace(/'|"/g,"")}';`}function tt(e,t){return k(t).map(n=>{const r=e.getPropertyValue(n),s=e.getPropertyPriority(n);return`${n}: ${r}${s?" !important":""};`}).join(" ")}function et(e,t,n,r){const s=`.${e}:${t}`,o=n.cssText?Z(n):tt(n,r);return document.createTextNode(`${s}{${o}}`)}function T(e,t,n,r){const s=window.getComputedStyle(e,n),o=s.getPropertyValue("content");if(o===""||o==="none")return;const i=X();try{t.className=`${t.className} ${i}`}catch{return}const a=document.createElement("style");a.appendChild(et(i,n,s,r)),t.appendChild(a)}function nt(e,t,n){T(e,t,":before",n),T(e,t,":after",n)}const R="application/font-woff",L="image/jpeg",rt={woff:R,woff2:R,ttf:"application/font-truetype",eot:"application/vnd.ms-fontobject",png:"image/png",jpg:L,jpeg:L,gif:"image/gif",tiff:"image/tiff",svg:"image/svg+xml",webp:"image/webp"};function st(e){const t=/\.([^./]*?)$/g.exec(e);return t?t[1]:""}function C(e){const t=st(e).toLowerCase();return rt[t]||""}function ot(e){return e.split(/,/)[1]}function S(e){return e.search(/^(data:)/)!==-1}function it(e,t){return`data:${t};base64,${e}`}async function H(e,t,n){const r=await fetch(e,t);if(r.status===404)throw new Error(`Resource "${r.url}" not found`);const s=await r.blob();return new Promise((o,i)=>{const a=new FileReader;a.onerror=i,a.onloadend=()=>{try{o(n({res:r,result:a.result}))}catch(c){i(c)}},a.readAsDataURL(s)})}const E={};function at(e,t,n){let r=e.replace(/\?.*/,"");return n&&(r=e),/ttf|otf|eot|woff2?/i.test(r)&&(r=r.replace(/.*\//,"")),t?`[${t}]${r}`:r}async function v(e,t,n){const r=at(e,t,n.includeQueryParams);if(E[r]!=null)return E[r];n.cacheBust&&(e+=(/\?/.test(e)?"&":"?")+new Date().getTime());let s;try{const o=await H(e,n.fetchRequestInit,({res:i,result:a})=>(t||(t=i.headers.get("Content-Type")||""),ot(a)));s=it(o,t)}catch(o){s=n.imagePlaceholder||"";let i=`Failed to fetch resource: ${e}`;o&&(i=typeof o=="string"?o:o.message),i&&console.warn(i)}return E[r]=s,s}async function ct(e){const t=e.toDataURL();return t==="data:,"?e.cloneNode(!1):b(t)}async function lt(e,t){if(e.currentSrc){const o=document.createElement("canvas"),i=o.getContext("2d");o.width=e.clientWidth,o.height=e.clientHeight,i?.drawImage(e,0,0,o.width,o.height);const a=o.toDataURL();return b(a)}const n=e.poster,r=C(n),s=await v(n,r,t);return b(s)}async function ut(e,t){var n;try{if(!((n=e?.contentDocument)===null||n===void 0)&&n.body)return await x(e.contentDocument.body,t,!0)}catch{}return e.cloneNode(!1)}async function ht(e,t){return d(e,HTMLCanvasElement)?ct(e):d(e,HTMLVideoElement)?lt(e,t):d(e,HTMLIFrameElement)?ut(e,t):e.cloneNode(A(e))}const dt=e=>e.tagName!=null&&e.tagName.toUpperCase()==="SLOT",A=e=>e.tagName!=null&&e.tagName.toUpperCase()==="SVG";async function ft(e,t,n){var r,s;if(A(t))return t;let o=[];return dt(e)&&e.assignedNodes?o=g(e.assignedNodes()):d(e,HTMLIFrameElement)&&(!((r=e.contentDocument)===null||r===void 0)&&r.body)?o=g(e.contentDocument.body.childNodes):o=g(((s=e.shadowRoot)!==null&&s!==void 0?s:e).childNodes),o.length===0||d(e,HTMLVideoElement)||await o.reduce((i,a)=>i.then(()=>x(a,n)).then(c=>{c&&t.appendChild(c)}),Promise.resolve()),t}function mt(e,t,n){const r=t.style;if(!r)return;const s=window.getComputedStyle(e);s.cssText?(r.cssText=s.cssText,r.transformOrigin=s.transformOrigin):k(n).forEach(o=>{let i=s.getPropertyValue(o);o==="font-size"&&i.endsWith("px")&&(i=`${Math.floor(parseFloat(i.substring(0,i.length-2)))-.1}px`),d(e,HTMLIFrameElement)&&o==="display"&&i==="inline"&&(i="block"),o==="d"&&t.getAttribute("d")&&(i=`path(${t.getAttribute("d")})`),r.setProperty(o,i,s.getPropertyPriority(o))})}function gt(e,t){d(e,HTMLTextAreaElement)&&(t.innerHTML=e.value),d(e,HTMLInputElement)&&t.setAttribute("value",e.value)}function pt(e,t){if(d(e,HTMLSelectElement)){const r=Array.from(t.children).find(s=>e.value===s.getAttribute("value"));r&&r.setAttribute("selected","")}}function wt(e,t,n){return d(t,Element)&&(mt(e,t,n),nt(e,t,n),gt(e,t),pt(e,t)),t}async function yt(e,t){const n=e.querySelectorAll?e.querySelectorAll("use"):[];if(n.length===0)return e;const r={};for(let o=0;o<n.length;o++){const a=n[o].getAttribute("xlink:href");if(a){const c=e.querySelector(a),l=document.querySelector(a);!c&&l&&!r[a]&&(r[a]=await x(l,t,!0))}}const s=Object.values(r);if(s.length){const o="http://www.w3.org/1999/xhtml",i=document.createElementNS(o,"svg");i.setAttribute("xmlns",o),i.style.position="absolute",i.style.width="0",i.style.height="0",i.style.overflow="hidden",i.style.display="none";const a=document.createElementNS(o,"defs");i.appendChild(a);for(let c=0;c<s.length;c++)a.appendChild(s[c]);e.appendChild(i)}return e}async function x(e,t,n){return!n&&t.filter&&!t.filter(e)?null:Promise.resolve(e).then(r=>ht(r,t)).then(r=>ft(e,r,t)).then(r=>wt(e,r,t)).then(r=>yt(r,t))}const D=/url\((['"]?)([^'"]+?)\1\)/g,bt=/url\([^)]+\)\s*format\((["']?)([^"']+)\1\)/g,xt=/src:\s*(?:url\([^)]+\)\s*format\([^)]+\)[,;]\s*)+/g;function Et(e){const t=e.replace(/([.*+?^${}()|\[\]\/\\])/g,"\\$1");return new RegExp(`(url\\(['"]?)(${t})(['"]?\\))`,"g")}function St(e){const t=[];return e.replace(D,(n,r,s)=>(t.push(s),n)),t.filter(n=>!S(n))}async function Ct(e,t,n,r,s){try{const o=n?_(t,n):t,i=C(t);let a;return s||(a=await v(o,i,r)),e.replace(Et(t),`$1${a}$3`)}catch{}return e}function vt(e,{preferredFontFormat:t}){return t?e.replace(xt,n=>{for(;;){const[r,,s]=bt.exec(n)||[];if(!s)return"";if(s===t)return`src: ${r};`}}):e}function B(e){return e.search(D)!==-1}async function U(e,t,n){if(!B(e))return e;const r=vt(e,n);return St(r).reduce((o,i)=>o.then(a=>Ct(a,i,t,n)),Promise.resolve(r))}async function w(e,t,n){var r;const s=(r=t.style)===null||r===void 0?void 0:r.getPropertyValue(e);if(s){const o=await U(s,null,n);return t.style.setProperty(e,o,t.style.getPropertyPriority(e)),!0}return!1}async function Tt(e,t){await w("background",e,t)||await w("background-image",e,t),await w("mask",e,t)||await w("-webkit-mask",e,t)||await w("mask-image",e,t)||await w("-webkit-mask-image",e,t)}async function Rt(e,t){const n=d(e,HTMLImageElement);if(!(n&&!S(e.src))&&!(d(e,SVGImageElement)&&!S(e.href.baseVal)))return;const r=n?e.src:e.href.baseVal,s=await v(r,C(r),t);await new Promise((o,i)=>{e.onload=o,e.onerror=t.onImageErrorHandler?(...c)=>{try{o(t.onImageErrorHandler(...c))}catch(l){i(l)}}:i;const a=e;a.decode&&(a.decode=o),a.loading==="lazy"&&(a.loading="eager"),n?(e.srcset="",e.src=s):e.href.baseVal=s})}async function Lt(e,t){const r=g(e.childNodes).map(s=>q(s,t));await Promise.all(r).then(()=>e)}async function q(e,t){d(e,Element)&&(await Tt(e,t),await Rt(e,t),await Lt(e,t))}function It(e,t){const{style:n}=e;t.backgroundColor&&(n.backgroundColor=t.backgroundColor),t.width&&(n.width=`${t.width}px`),t.height&&(n.height=`${t.height}px`);const r=t.style;return r!=null&&Object.keys(r).forEach(s=>{n[s]=r[s]}),e}const I={};async function P(e){let t=I[e];if(t!=null)return t;const r=await(await fetch(e)).text();return t={url:e,cssText:r},I[e]=t,t}async function $(e,t){let n=e.cssText;const r=/url\(["']?([^"')]+)["']?\)/g,o=(n.match(/url\([^)]+\)/g)||[]).map(async i=>{let a=i.replace(r,"$1");return a.startsWith("https://")||(a=new URL(a,e.url).href),H(a,t.fetchRequestInit,({result:c})=>(n=n.replace(i,`url(${c})`),[i,c]))});return Promise.all(o).then(()=>n)}function F(e){if(e==null)return[];const t=[],n=/(\/\*[\s\S]*?\*\/)/gi;let r=e.replace(n,"");const s=new RegExp("((@.*?keyframes [\\s\\S]*?){([\\s\\S]*?}\\s*?)})","gi");for(;;){const c=s.exec(r);if(c===null)break;t.push(c[0])}r=r.replace(s,"");const o=/@import[\s\S]*?url\([^)]*\)[\s\S]*?;/gi,i="((\\s*?(?:\\/\\*[\\s\\S]*?\\*\\/)?\\s*?@media[\\s\\S]*?){([\\s\\S]*?)}\\s*?})|(([\\s\\S]*?){([\\s\\S]*?)})",a=new RegExp(i,"gi");for(;;){let c=o.exec(r);if(c===null){if(c=a.exec(r),c===null)break;o.lastIndex=a.lastIndex}else a.lastIndex=o.lastIndex;t.push(c[0])}return t}async function Pt(e,t){const n=[],r=[];return e.forEach(s=>{if("cssRules"in s)try{g(s.cssRules||[]).forEach((o,i)=>{if(o.type===CSSRule.IMPORT_RULE){let a=i+1;const c=o.href,l=P(c).then(u=>$(u,t)).then(u=>F(u).forEach(h=>{try{s.insertRule(h,h.startsWith("@import")?a+=1:s.cssRules.length)}catch(m){console.error("Error inserting rule from remote css",{rule:h,error:m})}})).catch(u=>{console.error("Error loading remote css",u.toString())});r.push(l)}})}catch(o){const i=e.find(a=>a.href==null)||document.styleSheets[0];s.href!=null&&r.push(P(s.href).then(a=>$(a,t)).then(a=>F(a).forEach(c=>{i.insertRule(c,i.cssRules.length)})).catch(a=>{console.error("Error loading remote stylesheet",a)})),console.error("Error inlining remote css file",o)}}),Promise.all(r).then(()=>(e.forEach(s=>{if("cssRules"in s)try{g(s.cssRules||[]).forEach(o=>{n.push(o)})}catch(o){console.error(`Error while reading CSS rules from ${s.href}`,o)}}),n))}function $t(e){return e.filter(t=>t.type===CSSRule.FONT_FACE_RULE).filter(t=>B(t.style.getPropertyValue("src")))}async function Ft(e,t){if(e.ownerDocument==null)throw new Error("Provided element is not within a Document");const n=g(e.ownerDocument.styleSheets),r=await Pt(n,t);return $t(r)}function z(e){return e.trim().replace(/["']/g,"")}function kt(e){const t=new Set;function n(r){(r.style.fontFamily||getComputedStyle(r).fontFamily).split(",").forEach(o=>{t.add(z(o))}),Array.from(r.children).forEach(o=>{o instanceof HTMLElement&&n(o)})}return n(e),t}async function Mt(e,t){const n=await Ft(e,t),r=kt(e);return(await Promise.all(n.filter(o=>r.has(z(o.style.fontFamily))).map(o=>{const i=o.parentStyleSheet?o.parentStyleSheet.href:null;return U(o.cssText,i,t)}))).join(`
`)}async function Ht(e,t){const n=t.fontEmbedCSS!=null?t.fontEmbedCSS:t.skipFonts?null:await Mt(e,t);if(n){const r=document.createElement("style"),s=document.createTextNode(n);r.appendChild(s),e.firstChild?e.insertBefore(r,e.firstChild):e.appendChild(r)}}async function At(e,t={}){const{width:n,height:r}=M(e,t),s=await x(e,t,!0);return await Ht(s,t),await q(s,t),It(s,t),await Y(s,n,r)}async function Dt(e,t={}){const{width:n,height:r}=M(e,t),s=await At(e,t),o=await b(s),i=document.createElement("canvas"),a=i.getContext("2d"),c=t.pixelRatio||N(),l=t.canvasWidth||n,u=t.canvasHeight||r;return i.width=l*c,i.height=u*c,t.skipAutoScale||J(i),i.style.width=`${l}`,i.style.height=`${u}`,t.backgroundColor&&(a.fillStyle=t.backgroundColor,a.fillRect(0,0,i.width,i.height)),a.drawImage(o,0,0,i.width,i.height),i}async function Bt(e,t={}){return(await Dt(e,t)).toDataURL()}class Ut{async capture(t){const n=t.cloneNode(!0);this.copyEssentialTextStyles(t,n),this.removeUnwantedElements(n),await this.inlineImages(n),n.style.backgroundColor="white",n.style.padding="20px",n.style.borderRadius="12px",n.style.maxWidth="600px",n.style.opacity="1",n.style.visibility="visible",n.style.display="block";const r=document.createElement("div");r.style.cssText=`
      position: fixed;
      left: -99999px;
      top: -99999px;
      width: 600px;
      background: white;
      opacity: 0;
      pointer-events: none;
      z-index: 2147483647;
    `,r.appendChild(n),document.body.appendChild(r),r.offsetHeight,n.offsetHeight,await new Promise(a=>setTimeout(a,100));const s=this.calculateCaptureBounds(n),o=this.sanitizeCaptureDimension(s.width,600,"width"),i=this.sanitizeCaptureDimension(Math.max(s.height,n.scrollHeight,n.offsetHeight),1200,"height");r.style.width=`${o}px`,r.style.height=`${i}px`,n.style.width=`${o}px`,n.style.height="auto",n.style.minHeight="auto",r.offsetHeight,n.offsetHeight,await new Promise(a=>setTimeout(a,100));try{return await new Promise(c=>setTimeout(c,200)),await Bt(n,{width:o,height:i,pixelRatio:2,quality:1,backgroundColor:"#ffffff"})}catch(a){throw console.error("[XCapture] Capture failed:",a),a}finally{document.body.removeChild(r)}}copyEssentialTextStyles(t,n){const r=[t,...Array.from(t.querySelectorAll("*"))],s=[n,...Array.from(n.querySelectorAll("*"))],o=["color","font-family","font-size","font-weight","font-style","line-height","letter-spacing","text-decoration","text-decoration-color","text-decoration-line","text-transform","text-shadow","word-break","white-space"];r.forEach((i,a)=>{const c=s[a];if(!c||!(i instanceof HTMLElement)||!(c instanceof HTMLElement))return;const l=window.getComputedStyle(i),u=l.getPropertyValue("color");if(this.isTextBearingElement(i)){const h=this.normalizeDarkTextColor(u);h&&c.style.setProperty("color",h)}o.forEach(h=>{if(h==="color")return;const m=l.getPropertyValue(h);m&&c.style.setProperty(h,m)}),a===0&&c.style.setProperty("color","#0f1419","important")})}isTextBearingElement(t){const n=t.tagName.toLowerCase();return new Set(["img","svg","canvas","iframe","video","audio"]).has(n)||t.closest('[data-testid="tweetPhoto"]')||t.matches('[contenteditable="true"], input, textarea, button')?!1:t.textContent&&t.textContent.trim().length>0?!0:new Set(["a","abbr","b","blockquote","code","em","h1","h2","h3","h4","h5","h6","i","label","p","pre","q","s","span","strong","sub","sup","time","u"]).has(n)}normalizeDarkTextColor(t){if(!t)return null;const n=this.parseRgb(t);if(!n)return t;const[r,s,o]=n;return .299*r+.587*s+.114*o>160?"#0f1419":t}parseRgb(t){if(t.startsWith("rgb(")){const r=t.replace(/^rgb\((.+)\)$/i,"$1").split(",").map(s=>Number.parseInt(s.trim(),10));if(r.length>=3&&r.every(s=>Number.isFinite(s)))return[r[0],r[1],r[2]]}if(t.startsWith("rgba(")){const r=t.replace(/^rgba\((.+)\)$/i,"$1").split(",").slice(0,3).map(s=>Number.parseInt(s.trim(),10));if(r.length===3&&r.every(s=>Number.isFinite(s)))return[r[0],r[1],r[2]]}if(t.startsWith("#")){const r=t.slice(1);if(r.length===3){const s=Number.parseInt(r[0]+r[0],16),o=Number.parseInt(r[1]+r[1],16),i=Number.parseInt(r[2]+r[2],16);return[s,o,i]}if(r.length===6){const s=Number.parseInt(r.slice(0,2),16),o=Number.parseInt(r.slice(2,4),16),i=Number.parseInt(r.slice(4,6),16);return[s,o,i]}}const n=t.match(/hsl\s*\(\s*([\d.]+)\s*,\s*([\d.]+)%\s*,\s*([\d.]+)%\s*\)/i);if(n){const r=Number.parseFloat(n[1]),s=Number.parseFloat(n[2])/100,o=Number.parseFloat(n[3])/100;if([r,s,o].every(Number.isFinite)){const i=(1-Math.abs(2*o-1))*s,a=i*(1-Math.abs(r/60%2-1)),c=o-i/2;let l,u,h;return r>=0&&r<60?[l,u,h]=[i,a,0]:r<120?[l,u,h]=[a,i,0]:r<180?[l,u,h]=[0,i,a]:r<240?[l,u,h]=[0,a,i]:r<300?[l,u,h]=[a,0,i]:[l,u,h]=[i,0,a],[Math.round((l+c)*255),Math.round((u+c)*255),Math.round((h+c)*255)]}}return null}removeUnwantedElements(t){['[data-testid="caret"]','[data-testid="socialContext"]'].forEach(r=>{t.querySelectorAll(r).forEach(s=>{s instanceof HTMLElement&&s.remove()})})}async inlineImages(t){const n=t.querySelectorAll("img"),r=[];n.forEach(o=>{const i=o.src;i&&!i.startsWith("data:")&&r.push(this.convertImageToBase64(i).then(a=>{o.src=a}).catch(a=>{console.warn("[XCapture] Failed to convert img:",i.substring(0,100),a)}))}),t.querySelectorAll("*").forEach(o=>{if(o instanceof HTMLElement){const i=o.style.backgroundImage;if(i&&i!=="none"&&i.includes("url(")){const a=i.match(/url\(['"]?(.*?)['"]?\)/);if(a&&a[1]&&!a[1].startsWith("data:")){const c=a[1];r.push(this.convertImageToBase64(c).then(l=>{o.style.backgroundImage=`url(${l})`}).catch(l=>{console.warn("[XCapture] Failed to convert background image:",c.substring(0,100),l)}))}}}}),await Promise.all(r),await this.waitForImagesToLoad(t)}async waitForImagesToLoad(t){const n=t.querySelectorAll("img"),r=[];n.forEach((s,o)=>{s.complete&&s.naturalHeight!==0||r.push(new Promise(i=>{const a=setTimeout(()=>{console.warn(`[XCapture] img[${o}] load timeout`),i()},2e3);s.onload=()=>{clearTimeout(a),i()},s.onerror=()=>{clearTimeout(a),console.warn(`[XCapture] img[${o}] load error`),i()}}))}),await Promise.all(r)}calculateCaptureBounds(t){const n=t.getBoundingClientRect(),r=Number.isFinite(n.width)?n.width:0,s=Number.isFinite(n.height)?n.height:0;let o=s,i=r;t.querySelectorAll("*").forEach(l=>{if(l instanceof HTMLElement){const u=l.getBoundingClientRect(),h=u.left-n.left,m=u.top-n.top;Number.isFinite(u.width)&&Number.isFinite(u.height)&&Number.isFinite(h)&&Number.isFinite(m)&&u.width<5e3&&u.height<5e3&&Math.abs(h)<5e3&&Math.abs(m)<5e3&&(i=Math.max(i,h+u.width),o=Math.max(o,m+u.height))}});const a=Math.max(1,Math.ceil(i),Math.ceil(t.scrollWidth),Math.ceil(t.offsetWidth),Math.ceil(r)),c=Math.max(1,Math.ceil(o),Math.ceil(t.scrollHeight),Math.ceil(t.offsetHeight),Math.ceil(s));return{width:a,height:c}}sanitizeCaptureDimension(t,n,r){const s=r==="width"?1200:5e3;return Number.isFinite(t)?t<=0?(console.warn(`[XCapture] Non-positive ${r} bound ${t}, using fallback ${n}`),n):t>s?(console.warn(`[XCapture] Oversized ${r} bound ${t}, clamped to ${s}`),s):Math.round(t):(console.warn(`[XCapture] Invalid ${r} bound ${t}, using fallback ${n}`),n)}async convertImageToBase64(t){return new Promise((n,r)=>{const s=new Image;s.crossOrigin="anonymous",s.onload=()=>{try{const o=document.createElement("canvas");o.width=s.naturalWidth,o.height=s.naturalHeight;const i=o.getContext("2d");if(!i){r(new Error("Failed to get canvas context"));return}i.drawImage(s,0,0);const a=o.toDataURL("image/png");n(a)}catch(o){r(o)}},s.onerror=()=>{r(new Error("Failed to load image"))},s.src=t})}}async function qt(e){try{const n=await(await fetch(e)).blob();return await navigator.clipboard.write([new ClipboardItem({"image/png":n})]),!0}catch(t){return console.error("Failed to copy image to clipboard:",t),!1}}function zt(e,t){const n=document.createElement("a");n.href=e,n.download=t,document.body.appendChild(n),n.click(),document.body.removeChild(n)}function Vt(){return`xcapture-${new Date().toISOString().replace(/[:.]/g,"-")}.png`}class Wt{constructor(){this.modal=null,this.shadowHost=null,this.handleEscapeKey=null}show(t){this.modal=this.createModal(t),this.shadowHost=document.createElement("div"),this.shadowHost.attachShadow({mode:"closed"}).appendChild(this.modal),document.body.appendChild(this.shadowHost),this.handleEscapeKey=r=>{r.key==="Escape"&&this.close()},document.addEventListener("keydown",this.handleEscapeKey)}close(){this.handleEscapeKey&&(document.removeEventListener("keydown",this.handleEscapeKey),this.handleEscapeKey=null),this.shadowHost&&this.shadowHost.parentElement&&(this.shadowHost.remove(),this.modal=null,this.shadowHost=null)}showToast(t,n="success"){if(!this.modal)return;const r=document.createElement("div");r.className=`xcapture-toast xcapture-toast-${n}`,r.textContent=t,r.style.cssText=`
      position: fixed;
      bottom: 20px;
      right: 20px;
      padding: 12px 20px;
      border-radius: 8px;
      color: white;
      font-size: 14px;
      font-weight: 600;
      z-index: 10001;
      animation: slideIn 0.3s ease-out;
      background: ${n==="success"?"#10b981":"#ef4444"};
    `;const s=document.createElement("style");s.textContent=`
      @keyframes slideIn {
        from {
          transform: translateX(100%);
          opacity: 0;
        }
        to {
          transform: translateX(0);
          opacity: 1;
        }
      }
    `,this.modal.appendChild(s),this.modal.appendChild(r),setTimeout(()=>{r.style.animation="slideIn 0.3s ease-out reverse",setTimeout(()=>r.remove(),300)},2e3)}createModal(t){const n=document.createElement("div");return n.className="xcapture-modal",n.innerHTML=`
      <div class="xcapture-overlay"></div>
      <div class="xcapture-content">
        <div class="xcapture-header">
          <h2>截图预览</h2>
          <button class="xcapture-close">&times;</button>
        </div>
        <div class="xcapture-image-container">
          <img src="${t}" alt="Tweet Screenshot" />
        </div>
        <div class="xcapture-actions">
          <button class="xcapture-btn xcapture-copy">复制到剪贴板</button>
          <button class="xcapture-btn xcapture-download">下载图片</button>
        </div>
      </div>
    `,this.attachEventListeners(n,t),this.injectStyles(n),n}attachEventListeners(t,n){const r=t.querySelector(".xcapture-close"),s=t.querySelector(".xcapture-copy"),o=t.querySelector(".xcapture-download");r?.addEventListener("click",()=>this.close()),s?.addEventListener("click",async()=>{await qt(n)?this.showToast("✓ 图片已复制到剪贴板","success"):this.showToast("✗ 复制失败，请重试","error")}),o?.addEventListener("click",()=>{zt(n,Vt()),this.showToast("✓ 图片已开始下载","success")})}injectStyles(t){const n=`
      .xcapture-modal {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        z-index: 10000;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
      }

      .xcapture-overlay {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.7);
      }

      .xcapture-content {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        background: white;
        border-radius: 16px;
        max-width: 90%;
        max-height: 90%;
        overflow: auto;
        box-shadow: 0 4px 20px rgba(0, 0, 0, 0.3);
      }

      .xcapture-header {
        display: flex;
        justify-content: space-between;
        align-items: center;
        padding: 16px 20px;
        border-bottom: 1px solid #e1e8ed;
      }

      .xcapture-header h2 {
        margin: 0;
        font-size: 20px;
        font-weight: 700;
      }

      .xcapture-close {
        background: none;
        border: none;
        font-size: 28px;
        cursor: pointer;
        color: #657786;
        padding: 0;
        line-height: 1;
      }

      .xcapture-close:hover {
        color: #1da1f2;
      }

      .xcapture-image-container {
        padding: 20px;
        max-height: 60vh;
        overflow: auto;
      }

      .xcapture-image-container img {
        max-width: 100%;
        height: auto;
        display: block;
      }

      .xcapture-actions {
        display: flex;
        gap: 12px;
        padding: 16px 20px;
        border-top: 1px solid #e1e8ed;
      }

      .xcapture-btn {
        flex: 1;
        padding: 12px 20px;
        border: none;
        border-radius: 9999px;
        font-size: 15px;
        font-weight: 700;
        cursor: pointer;
        transition: background-color 0.2s;
      }

      .xcapture-copy {
        background-color: #1da1f2;
        color: white;
      }

      .xcapture-copy:hover {
        background-color: #1a91da;
      }

      .xcapture-download {
        background-color: #14171a;
        color: white;
      }

      .xcapture-download:hover {
        background-color: #0f1316;
      }
    `,r=document.createElement("style");r.textContent=n,t.appendChild(r)}}class Ot{constructor(){this.detector=new W,this.injector=new j,this.capture=new Ut}async init(){await this.detector.start(t=>{this.handleTweet(t)})}handleTweet(t){this.injector.inject(t,()=>{this.handleScreenshot(t)})}showLoading(){const t=document.createElement("div");t.id="xcapture-loading",t.innerHTML=`
      <div class="xcapture-loading-content">
        <div class="xcapture-spinner"></div>
        <div class="xcapture-loading-text">正在生成截图...</div>
      </div>
    `;const n=document.createElement("style");return n.textContent=`
      #xcapture-loading {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background: rgba(0, 0, 0, 0.8);
        display: flex;
        align-items: center;
        justify-content: center;
        z-index: 9999;
        animation: fadeIn 0.2s ease-in;
      }
      
      .xcapture-loading-content {
        text-align: center;
        color: white;
      }
      
      .xcapture-spinner {
        width: 50px;
        height: 50px;
        border: 4px solid rgba(255, 255, 255, 0.3);
        border-top-color: #1da1f2;
        border-radius: 50%;
        margin: 0 auto 20px;
        animation: spin 1s linear infinite;
      }
      
      .xcapture-loading-text {
        font-size: 18px;
        font-weight: 600;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif;
      }
      
      @keyframes spin {
        to { transform: rotate(360deg); }
      }
      
      @keyframes fadeIn {
        from { opacity: 0; }
        to { opacity: 1; }
      }
    `,t.appendChild(n),document.body.appendChild(t),t}hideLoading(t){t&&t.parentElement&&t.remove()}async handleScreenshot(t){const n=this.showLoading();try{const r=await this.capture.capture(t);this.hideLoading(n),new Wt().show(r)}catch(r){this.hideLoading(n),console.error("Failed to capture screenshot:",r),alert("截图失败，请重试")}}}const jt=new Ot;jt.init();
